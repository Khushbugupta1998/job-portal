import React from 'react'

const About = () => {
  return (
    <>
    <h1 className='text-center text-2xl mt-10'>About Page</h1>
    </>
  )
}

export default About